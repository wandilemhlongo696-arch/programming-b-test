/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package programming.b.test;

/**
 *
 * @author Student
 */
public class question2 {
    
}
 public abstract class Beverage implements IBeverage {

    private String beverageType;
    private String city;
    private int totalSales;

    public Beverage(String beverageType, String city, int totalSales) {
        this.beverageType = beverageType;
        this.city = city;
        this.totalSales = totalSales;
    }

    @Override
    public String getBeverageType() {
        return beverageType;
    }

    @Override
    public String getCity() {
        return city;
    }

    @Override
    public int getTotalSales() {
        return totalSales;
    }

    // Implemented by subclasses
    public abstract void printReport();
}

public class BeverageSales extends Beverage {

    public BeverageSales(String beverageType, String city, int totalSales) {
        super(beverageType, city, totalSales);
    }

    @Override
    public void printReport() {
        System.out.println("Beverage Type : " + getBeverageType());
        System.out.println("City          : " + getCity());
        System.out.println("Total Sales   : " + getTotalSales());
        System.out.println("-----------------------------------");
    }
}

import java.util.ArrayList;
import java.util.Scanner;

public class Run {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        ArrayList<BeverageSales> records = new ArrayList<>();
        String[] beverages = {"Coffee", "Tea", "Boba Tea"};

        String again;
        do {
            System.out.println("Select a beverage type:");
            for (int i = 0; i < beverages.length; i++) {
                System.out.println((i + 1) + ". " + beverages[i]);
            }

            int choice;
            do {
                System.out.print("Enter choice (1-3): ");
                while (!input.hasNextInt()) {
                    System.out.print("Invalid. Enter choice (1-3): ");
                    input.next();
                }
                choice = input.nextInt();
            } while (choice < 1 || choice > 3);
            input.nextLine();

            System.out.print("Enter the city: ");
            String city = input.nextLine();

            System.out.print("Enter the total sales: ");
            while (!input.hasNextInt()) {
                System.out.print("Invalid. Enter the total sales: ");
                input.next();
            }
            int sales = input.nextInt();
            input.nextLine();

            records.add(new BeverageSales(beverages[choice - 1], city, sales));

            System.out.print("Add another record? (y/n): ");
            again = input.nextLine();
            System.out.println();
        } while (again.equalsIgnoreCase("y"));

        System.out.println("====== NUMBER 1 COFFEE HUT SALES REPORT ======");
        int grandTotal = 0;
        for (BeverageSales record : records) {
            record.printReport();
            grandTotal += record.getTotalSales();
        }
        System.out.println("Total sales for Number 1 Coffee Hut: " + grandTotal);
    }
}