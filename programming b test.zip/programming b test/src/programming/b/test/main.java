package programming.b.test;

/**
 *
 * @author Student
 */
public class main coffeHutReport {
    @SuppressWarnings("empty-statement")
    public static void main(string[] args){
        // Single array: city names 
        String []cities ={"cape town","port elizabeth","pretoria"};
        // single array: bavarages names 
        String []bavarages = {"coffe","tea","boba tea"};
        // Two dimensional arrray: sales [city][bavarage]
       int[][] sales = {
        {500, 300, 125}, // Cape Town
           {450, 250, 100}, // Port Elizabeth
           {480, 175, 120}, // Pretoria
        };
       // single array: total sales per city
       int[]citytotals = new int[cities.length];
       system.out.println("-----------NUMBER 1 COFFE HUT BEVERAGE REPORT-----------");
       System.out.println();
        String GrandTotal = null;
       
       for (int i = 0 ; i < cities.length; i++){
           System.out.println("city" +cities[i]);
           for (int j = 0; j< beverages.length; j++){
               System.out.println("%-10s:%d%n", beverages[j], sales [i][j]); Citytotals[i]+= sales[i][j];
           }
           System.out.println("   total sales for "+ cities[i]+":"+ citytotals[i]);
           System.out.println();
           
           GrandTotal += CityTotals[i];
       }
       System.out.println("-------------------------");
       System.out.println(" Total sales for all cities:" + GrandTotal);
       System.out.println("--------------------------");    
    }
}
